This folder contains a version of Metawidget (metawidget-debug-version.jar) compiled with debug information on.

This results in a larger JAR size, but may be useful to obtain line numbers while debugging.
