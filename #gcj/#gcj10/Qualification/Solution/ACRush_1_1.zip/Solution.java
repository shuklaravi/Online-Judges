import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.StringTokenizer;


public class Solution
{
	final String filename = "E:\\LTC\\GCJ2010\\Qualification\\B\\B-large";
	BufferedReader in;
	PrintWriter out;
	StringTokenizer st;
	
	Solution()
	{
		try
		{
			in = new BufferedReader(new FileReader(filename + ".in"));
			out = new PrintWriter(filename + ".out");
			readData("");
			int testcases = nextInt();
			for (int caseId = 1; caseId <= testcases; caseId++)
			{
				System.out.println("case: " + caseId);
				out.print("Case #" + caseId + ": ");
				int n = nextInt();
				BigInteger a[] = new BigInteger[n];
				for (int i = 0; i < n; i++)
					a[i] = new BigInteger(nextString());
				int oldn = n;
				n = 0;
				for (int i = 0; i < oldn; i++)
				{
					boolean exists = false;
					for (int k = 0; k < n; k++)
						if (a[i].compareTo(a[k]) == 0)
							exists = true;
					if (!exists)
						a[n++] = a[i];
				}
				if (n == 1)
				{
					out.println("0");
					continue;
				}
				BigInteger m = BigInteger.ZERO;
				for (int i = 1; i < n; i++) m = m.gcd(a[i].subtract(a[0]).abs());
				out.println(m.subtract(a[0].mod(m)).mod(m));
			}			
			in.close();
			out.close();
			System.out.println("done.");
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			System.exit(-1);
		}
	}
	
	private void readData(String string)
	{
		st = new StringTokenizer(string);
	}
	
	String next() throws IOException
	{
		while (!st.hasMoreTokens())
		{
			String line = in.readLine();
			if (line == null) {
				return null;
			}
			readData(line);
		}
		return st.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}
	
	long nextLong() throws IOException
	{
		return Long.parseLong(next());
	}
	
	double nextDouble() throws IOException
	{
		return Double.parseDouble(next());
	}
	
	short nextShort() throws IOException
	{
		return Short.parseShort(next());
	}
	
	String nextString() throws IOException
	{
		return next();
	}

	public static void main(String[] args)
	{
		new Solution();
	}
	
}
