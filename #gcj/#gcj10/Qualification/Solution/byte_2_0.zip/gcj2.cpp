#include<iostream>
#include<map>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<string>
#include<sstream>
#define inint(n) scanf("%d",&n);
#define instr(n) scanf("%s",&n);
#define inchar(n) scanf("%c",&n);
#define infloat(n) scanf("%f",&n);
#define FOR(a,b) for(int i=a;i<b;i++)
#define MAX(a,b) a>b?a:b
#define MIN(a,b) a>b?b:a

using namespace std;
int main()
{
   queue< long long > q;
   long long c,r,k,n,i,val,t,s,money,g=0,m;
   cin>>c;
   while(c--){while(!q.empty()) q.pop(); money=0;
              cin>>r>>k>>n;
              for(i=0;i<n;i++){ cin>>val; q.push(val); }
              while(r--) { t=0;  m=0; while(t+q.front()<=k) { m++; s=q.front(); t+=s; q.pop(); q.push(s); if(m==n){ break;} } money+=t; }
              printf("Case #%d: ",++g); cout<<money<<"\n";
              }
    return 0;
}
