#include<iostream>
#include<map>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<string>
#include<sstream>
#define inint(n) scanf("%d",&n);
#define instr(n) scanf("%s",&n);
#define inchar(n) scanf("%c",&n);
#define infloat(n) scanf("%f",&n);
#define FOR(a,b) for(int i=a;i<b;i++)
#define MAX(a,b) a>b?a:b
#define MIN(a,b) a>b?b:a

using namespace std;
int main()
{
long long r,k,n,c,arr[1005],cost[1005],money,end[1005],next,y,m,s,g=0;
cin>>c;
while(c--){
           cin>>r>>k>>n;
           for(int i=0;i<n;i++){ cin>>arr[i]; }
           for(int i=0;i<n;i++){ y=0; cost[i]=0; m=0; s=i; 
                   while(y+arr[s]<=k){ m++; y+=arr[s]; s++; if(m==n) break;  if(s>=n) s=0; }
                   cost[i]=y; if(s>=n) s=0; end[i]=s;
                   } money=0; s=0;
                   while(r--){ money+=cost[s]; s=end[s]; }
                   printf("Case #%d: ",++g); cout<<money<<"\n";
           }
           

    return 0;
}
