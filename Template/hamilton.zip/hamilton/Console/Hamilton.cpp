/*
 
 http://www.geocities.com/dharwadker/hamilton/ 

 A NEW ALGORITHM FOR FINDING HAMILTONIAN CIRCUITS  

 COPYRIGHT (C) 2004 BY ASHAY DHARWADKER

 H-501 PALAM VIHAR 
 DISTRICT  GURGAON 
 HARYANA  1 2 2 0 1 7 
 INDIA 
 
 dharwadker@yahoo.com

*/

#include <iostream> 
#include <fstream> 
#include <string> 
#include <vector> 
using namespace std;
vector<vector<int> > find_paths(vector<vector<int> > graph);
vector<int> procedure_1(vector< vector<int> > graph, vector<int> path); 
vector<int> procedure_2(vector< vector<int> > graph, vector<int> path); 
vector<int> procedure_2b(vector< vector<int> > graph, vector<int> path);
vector<int> procedure_2c(vector< vector<int> > graph, vector<int> path);
vector<int> procedure_3(vector< vector<int> > graph, vector<int> path);
vector<int> sort(vector<vector<int> > graph);
vector<vector<int> > reindex(vector<vector<int> > graph, vector<int> index);
vector<int> reverse(vector<int> path);
vector<int> concatenate(vector<vector<int> > graph, vector<int> path0, vector<int> path1);
vector<vector<int> > check_exceptional(vector<vector<int> > graph);
vector<vector<int> > find_paths_exceptional(vector<vector<int> > graph, vector<vector<int> > degree_one);
vector<int> find_circuit_exceptional(vector<vector<int> > graph);

ifstream infile ("graph.txt");      //Input file 
ofstream outfile("paths.txt");      //Output file 

int main() 
{ 
 int i, j, k, n, vertex, edge; 
 infile>>n;                         //Read number of vertices 
 vector< vector<int> > graph;       //Read adjacency matrix of graph 
 for(i=0; i<n; i++) 
 { 
  vector<int> row; 
  for(j=0; j<n; j++) 
  { 
   infile>>edge; 
   row.push_back(edge); 
  } 
  graph.push_back(row); 
 }
 vector<vector<int> > paths;
 vector<vector<int> > degree_one=check_exceptional(graph);
 int exceptional=degree_one.size();
 bool tour_exceptional=false, circuit_exceptional=true;
 bool tour_found=false, circuit_found=false;
 if(exceptional==2) tour_exceptional=true;
 if(exceptional>0) circuit_exceptional=false;
 if(tour_exceptional) paths=find_paths_exceptional(graph,degree_one);
 else paths=find_paths(graph);
 for(i=0; i<paths.size(); i++)
 {
   k=paths[i].size();
   if(k<n) outfile<<"Path("<<k<<"): ";
   else
    {
     tour_found=true;
     outfile<<"Hamiltonian Tour: ";
    }
   for(j=0; j<paths[i].size(); j++) outfile<<paths[i][j]+1<<" ";
   outfile<<endl;
   if(k==n && circuit_exceptional)
   {
    vector<int> circuit_maker=procedure_3(graph,paths[i]);
    if(!circuit_maker.empty())
    {
     for(j=0; j<circuit_maker.size(); j++)
     {
      circuit_found=true;
      outfile<<"Hamiltonian Circuit:\t";
      for(k=0; k<=circuit_maker[j]; k++)
       outfile<<paths[i][k]+1<<" ";
      for(k=n-1; k>circuit_maker[j]; k--)
       outfile<<paths[i][k]+1<<" ";
      outfile<<endl;
     }
    }
    outfile<<endl;
   }
 }
 if(tour_found) cout<<"Found Hamiltonian tour."<<endl;
 else cout<<"No Hamiltonian tours found."<<endl;
 if(circuit_exceptional==true && tour_found==true && circuit_found==false)
 {
   cout<<"finding circuits...";
   vector<int> circuit=find_circuit_exceptional(graph);
   if(!circuit.empty())
   {
    circuit_found=true;
    outfile<<"Hamiltonian Circuit:\t";
    for(k=0; k<circuit.size(); k++)
     outfile<<circuit[k]+1<<" ";
    outfile<<endl;
   }
  cout<<"\r";
 }
 if(circuit_found) cout<<"Found Hamiltonian circuit."<<endl;
 else cout<<"No Hamiltonian circuits found."<<endl;
 cout<<"See paths.txt for results."<<endl; 
 system("PAUSE");
 return 0;
} 

vector<vector<int> > find_paths(vector<vector<int> > graph)
{
 int i, k, n, vertex;
 n=graph.size();
 vector<int> index=sort(graph);
 graph=reindex(graph,index);
 vector<vector<int> > paths;
 for(vertex=0; vertex<n; vertex++)  //Loop through all vertices 
 { 
  vector<int> path; 
  path.push_back(vertex);            //Select initial vertex 
  path=procedure_1(graph,path);      //Part I 
  path=procedure_2(graph,path);      //Part II 
  k=path.size();                     
  if(k<n)   {path=procedure_2b(graph,path); k=path.size();}
  if(k<n)   {path=procedure_2c(graph,path); k=path.size();}
  vector<int> indexedpath;
  for(i=0; i<path.size(); i++) indexedpath.push_back(index[path[i]]);
  paths.push_back(indexedpath);
 }
 return paths;
}

vector<int> procedure_1(vector< vector<int> > graph, vector<int> path) 
{ 
 int i, j, k, n=graph.size(); 
 vector<int> extended_path; 
 vector<int> visited; 
 for(i=0; i<n; i++) 
  visited.push_back(0); 
 int present; 
 for(i=0; i<path.size(); i++) 
 { 
  present=path[i]; 
  visited[present]=1; 
  extended_path.push_back(present); 
 } 
 for(k=0; k<n; k++) 
 { 
  vector<int> neighbor;  
  for(i=0; i<n; i++) 
   if(graph[present][i]==1 && visited[i]==0) 
    neighbor.push_back(i); 
   if(!neighbor.empty()) 
   { 
    int choice=neighbor[0]; 
    int minimum=n; 
    for(i=0; i<neighbor.size(); i++) 
    { 
     vector<int> next_neighbor; 
     for(j=0; j<n; j++)  
      if(graph[neighbor[i]][j]==1 && visited[j]==0) 
       next_neighbor.push_back(j); 
      int eta=next_neighbor.size(); 
      if(eta<minimum)  
      { 
       choice=neighbor[i]; 
       minimum=eta; 
      } 
    } 
    present=choice;  
    visited[present]=1;  
    extended_path.push_back(present); 
   } 
   else break; 
 } 
 return extended_path; 
} 

vector<int> procedure_2(vector< vector<int> > graph, vector<int> path) 
{ 
 int i, j, k, n=graph.size();
 bool quit=false;
 while(quit!=true) 
 { 
 int m=path.size(), inlet=-1, outlet=-1;
  vector<int> neighbor; 
  for(i=0; i<path.size(); i++)  
   if(graph[path[m-1]][path[i]]==1) neighbor.push_back(i); 
   vector<int> unvisited; 
   for(i=0; i<n; i++)  
   { 
    bool outside=true; 
    for(j=0; j<path.size(); j++) 
     if(i==path[j]) outside=false; 
     if(outside==true) unvisited.push_back(i); 
   } 
   if((!unvisited.empty()) && (!neighbor.empty())) 
   { 
    int maximum=0; 
    for(i=0; i<neighbor.size(); i++) 
     for(j=0; j<unvisited.size(); j++) 
      if(graph[path[neighbor[i]+1]][unvisited[j]]==1) 
      { 
       vector<int> next_neighbor; 
       for(k=0; k<unvisited.size(); k++) 
        if(graph[unvisited[j]][unvisited[k]]==1) 
         next_neighbor.push_back(unvisited[k]); 
        int eta=next_neighbor.size(); 
        if(eta>maximum)
        { 
         inlet=neighbor[i]; 
         outlet=unvisited[j]; 
         maximum=eta; 
        } 
      } 
   } 
   vector<int> extended_path; 
   if(inlet!=-1 && outlet!=-1) 
   { 
    for(i=0; i<=inlet; i++) 
     extended_path.push_back(path[i]); 
    for(i=path.size()-1; i>inlet; i--) 
     extended_path.push_back(path[i]); 
    extended_path.push_back(outlet); 
   } 
   if(!extended_path.empty()) path=extended_path; 
   if(m<path.size()) path=procedure_1(graph,path); 
   else quit=true; 
 }
 return path; 
} 

vector<int> procedure_2b(vector< vector<int> > graph, vector<int> path)
{ 
 int i, j, k, l, p, n=graph.size();
 bool quit=false;
 while(quit!=true) 
 { 
  vector<int> extended_path; 
  int m=path.size();
  vector<int> unvisited;
  for(i=0; i<n; i++)
  {
    bool outside=true; 
    for(j=0; j<path.size(); j++) 
     if(i==path[j]) outside=false; 
    if(outside==true) unvisited.push_back(i);
  }
  bool big_check=false;
  for(i=0; i<path.size(); i++)
  {
    for(j=0; j<unvisited.size(); j++)
    {
     if(graph[unvisited[j]][path[i]]==1)
     {
       vector<int> temp_path;
       temp_path.push_back(unvisited[j]);
       vector<int> temp_extended_path;
       vector<int> temp_visited;
       for(l=0; l<n; l++)
       temp_visited.push_back(0);
       int present;
       for(l=0; l<temp_path.size(); l++)
       {
        present=temp_path[l];
        temp_visited[present]=1;
        temp_extended_path.push_back(present);
       }
       for(l=0; l<n; l++)
       {
        bool unfound=true;
        for(k=0; k<unvisited.size(); k++)
         if(l==unvisited[k]) unfound=false;
        if(unfound==true) temp_visited[l]=1;
       }
       for(l=0; l<n; l++)
       {
        vector<int> neighbor;
        for(l=0; l<n; l++)
        if(graph[present][l]==1 && temp_visited[l]==0)
        neighbor.push_back(l);
        if(!neighbor.empty())
        {
          int choice=neighbor[0];
          int minimum=n;
          for(l=0; l<neighbor.size(); l++)
          {
           vector<int> next_neighbor;
           for(k=0; k<n; k++)
            if(graph[neighbor[l]][k]==1 && temp_visited[k]==0)
            next_neighbor.push_back(k);
            int eta=next_neighbor.size();
            if(eta<minimum)
            {
             choice=neighbor[l];
             minimum=eta;
            }
          }
          present=choice;
          temp_visited[present]=1;
         temp_extended_path.push_back(present);
        }
       else break;
     }
     int last_vertex=temp_extended_path[temp_extended_path.size()-1];
     int vj;
     bool check=false;
     while(check==false && !temp_extended_path.empty())
     {
     for(p=path.size()-2; p>i; p--)
     {
      if(graph[path[p]][last_vertex]==1 && graph[path[i+1]][path[p+1]]==1)
      {
       check=true;
       vj=p;
       break;
      }
     }
     if(check==false)
     {
      temp_extended_path.pop_back();
      last_vertex=temp_extended_path[temp_extended_path.size()-1];
     }
     }
     if(check==true)
     {
      vector<int> temp;
      for(p=0; p<=i; p++)
      temp.push_back(path[p]);
      for(p=0; p<temp_extended_path.size(); p++)
      temp.push_back(temp_extended_path[p]);
      for(p=vj; p>i; p--)
      temp.push_back(path[p]);
      for(p=vj+1; p<path.size(); p++)
      temp.push_back(path[p]);
      temp_extended_path=temp;
      big_check=true;
      extended_path=temp_extended_path;
     }
     }
    }
     if(big_check==true)
     {
      break;
     }
  }
   if(!extended_path.empty()) path=extended_path; 
   if(m<path.size()) {path=procedure_1(graph,path); path=procedure_2(graph,path);}
   else quit=true; 
 }
 return path; 
} 

vector<int> procedure_2c(vector< vector<int> > graph, vector<int> path)
{ 
  vector<int> reversed_path;
  for(int i=path.size()-1; i>=0; i--) reversed_path.push_back(path[i]);
  reversed_path=procedure_2b(graph,reversed_path);
  return reversed_path;
}

vector<int> procedure_3(vector< vector<int> > graph, vector<int> path) 
{ 

 int i, n=path.size();

 vector<int> circuit_maker; 
 for(i=0; i<n-1; i++) 
  if((graph[path[0]][path[i+1]]==1) && (graph[path[i]][path[n-1]]==1))
   circuit_maker.push_back(i);
 return circuit_maker; 
}

vector<int> sort(vector<vector<int> > graph)
{
 int i, j;
 vector<int> degree;
 for(i=0; i<graph.size(); i++)
 {
  int sum=0;
  for(j=0; j<graph[i].size(); j++)
  if(graph[i][j]==1) sum++;
  degree.push_back(sum);
 }
 vector<int> index;
 for(i=0; i<degree.size(); i++) index.push_back(i);
 for(i=0; i<degree.size(); i++)
 for(j=i+1; j<degree.size(); j++)
 if(degree[i]<degree[j]) swap(index[i],index[j]);
 return index;
}

vector<vector<int> > reindex(vector<vector<int> > graph, vector<int> index)
{
  int i, j;
  vector<vector<int> > temp=graph;
  for(i=0; i<temp.size(); i++)
  for(j=0; j<temp[i].size(); j++)
  temp[i][j]=graph[index[i]][index[j]];
  return temp;
}

vector<int> reverse(vector<int> path)
{
 vector<int> vec;
 for(int i=path.size()-1; i>=0; i--)
 vec.push_back(path[i]);
 return vec;
}

vector<int> concatenate(vector<vector<int> > graph, vector<int> path0, vector<int> path1)
{
 int i,j,k,l,x=-1,y=-1;
 vector<int> path;

 for(i=path1.size()-1; i>=0; i--)
 {
  for(j=path0.size()-1; j>=0; j--)
  {
   if(graph[path1[i]][path0[j]]==1)
   {
    bool check=true;
    for(k=0; k<=i; k++)
    for(l=0; l<=j; l++)
    if(path1[k]==path0[l])
    check=false;
    if(check==true)
    {
     x=j;
     y=i;
     break;
    }
   }
  }
  if(x!=-1 && y!=-1) break;
 }
 if(x!=-1 && y!=-1)
 {
  for(i=0; i<=x; i++) path.push_back(path0[i]);
  for(j=y; j>=0; j--) path.push_back(path1[j]);
 }
 else path=path0;
 return path;
}

vector<vector<int> > check_exceptional(vector<vector<int> > graph)
{
 int i,j;
 vector<vector<int> > handles;
 vector<int> degree, temp, degree_one;
 for(i=0; i<graph.size(); i++)
 {
  int sum=0;
  for(j=0; j<graph[i].size(); j++)
  if(graph[i][j]==1) sum++;
  if(sum==1) degree_one.push_back(i);
  degree.push_back(sum);
 }
 if(degree_one.size()==1 || degree_one.size()==2)
 {
  vector<int> handle1;
  int present=degree_one[0];
  vector<int> visited;
  for(i=0; i<graph.size(); i++) visited.push_back(0);
  bool quit=false;
  while(!quit)
  {
   quit=true;
   handle1.push_back(present);
   visited[present]=1;
   for(i=0; i<graph.size(); i++)
   if(graph[present][i]==1 && degree[i]==2 && visited[i]==0 && quit==true)
    {
     present=i;
     quit=false;
    }
  }
 handles.push_back(handle1);
 if(degree_one.size()==2)
 {
  vector<int> handle2;
  present=degree_one[1];
  quit=false;
  while(!quit)
  {
   quit=true;
   handle2.push_back(present);
   visited[present]=1;
   for(i=0; i<graph.size(); i++)
   if(graph[present][i]==1 && degree[i]==2 && visited[i]==0 && quit==true)
    {
    present=i;
    quit=false;
    }
   }
   handles.push_back(handle2);
  }
 }
 return handles;
}

vector<vector<int> > find_paths_exceptional(vector<vector<int> > graph, vector<vector<int> > degree_one)
{
 int i,j,k;

 vector<vector<int> > graph0=graph;
 for(i=0; i<graph.size(); i++)
 for(j=0; j<graph[i].size(); j++)
 {
  bool check=false;
  for(k=0; k<degree_one[0].size(); k++) if(i==degree_one[0][k]) check=true;
  for(k=0; k<degree_one[1].size()-1; k++) if(i==degree_one[1][k]) check=true;
  for(k=0; k<degree_one[0].size(); k++) if(j==degree_one[0][k]) check=true;
  for(k=0; k<degree_one[1].size()-1; k++) if(j==degree_one[1][k]) check=true;
  if(check==true)
  graph0[i][j]=0;
 }
 vector<vector<int> > temp_paths0=find_paths(graph0);
 vector<vector<int> > paths0;
 for(i=0; i<temp_paths0.size(); i++)
 {
  vector<int> path0=temp_paths0[i];
  path0=procedure_1(graph,path0);
  path0=procedure_2(graph,path0);
  path0=procedure_2b(graph,path0);
  path0=procedure_2c(graph,path0);
  paths0.push_back(path0);
 }

 vector<vector<int> > graph1=graph;
 for(i=0; i<graph.size(); i++)
 for(j=0; j<graph[i].size(); j++)
 {
  bool check=false;
  for(k=0; k<degree_one[0].size()-1; k++) if(i==degree_one[0][k]) check=true;
  for(k=0; k<degree_one[1].size(); k++) if(i==degree_one[1][k]) check=true;
  for(k=0; k<degree_one[0].size()-1; k++) if(j==degree_one[0][k]) check=true;
  for(k=0; k<degree_one[1].size(); k++) if(j==degree_one[1][k]) check=true;
  if(check==true)
  graph1[i][j]=0;
 }

 vector<vector<int> > temp_paths1=find_paths(graph1);
 vector<vector<int> > paths1;
 for(i=0; i<temp_paths1.size(); i++)
 {
  vector<int> path1=temp_paths1[i];
  path1=procedure_1(graph,path1);
  path1=procedure_2(graph,path1);
  path1=procedure_2b(graph,path1);
  path1=procedure_2c(graph,path1);
  paths1.push_back(path1);
 }


vector<vector<int> > paths;
bool found=false;
for(i=0; i<paths0.size(); i++)
{
 if(found==true) break;
 for(j=0; j<paths1.size(); j++)
 {
  vector<int> p;

 p=concatenate(graph,paths0[i],paths1[j]);
 p=procedure_1(graph,p);
 p=procedure_2(graph,p);
 p=procedure_2b(graph,p);
 p=procedure_2c(graph,p);
 paths.push_back(p);
 if(p.size()==graph.size()) {found=true; break;}

 p=concatenate(graph,paths0[i],reverse(paths1[j]));
 p=procedure_1(graph,p);
 p=procedure_2(graph,p);
 p=procedure_2b(graph,p);
 p=procedure_2c(graph,p);
 paths.push_back(p);
 if(p.size()==graph.size()) {found=true; break;}

 p=concatenate(graph,reverse(paths0[i]),paths1[j]);
 p=procedure_1(graph,p);
 p=procedure_2(graph,p);
 p=procedure_2b(graph,p);
 p=procedure_2c(graph,p);
 paths.push_back(p);
 if(p.size()==graph.size()) {found=true; break;}

 p=concatenate(graph,reverse(paths0[i]),reverse(paths1[j]));
 p=procedure_1(graph,p);
 p=procedure_2(graph,p);
 p=procedure_2b(graph,p);
 p=procedure_2c(graph,p);
 paths.push_back(p);
 if(p.size()==graph.size()) {found=true; break;}
}
}
 return paths;
}

vector<int> find_circuit_exceptional(vector<vector<int> > graph)
{
 int i,j,k,l;
 vector<int> circuit;
 for(i=0; i<graph.size(); i++)
 {
  for(j=i+1; j<graph[i].size(); j++)
  {
   if(graph[i][j]==1)
   {
     vector<vector<int> > _graph=graph;
     _graph[i][j]=0;
     _graph[j][i]=0;
     vector<int> row1, row2;
     for(k=0; k<graph.size(); k++){
     if(k==i) {_graph[k].push_back(1);_graph[k].push_back(0); row1.push_back(1); row2.push_back(0);}
     else if(k==j) {_graph[k].push_back(0);_graph[k].push_back(1); row1.push_back(0); row2.push_back(1);}
     else {_graph[k].push_back(0);_graph[k].push_back(0); row1.push_back(0); row2.push_back(0);}
     }
     row1.push_back(0); row1.push_back(0);
     row2.push_back(0); row2.push_back(0);
     _graph.push_back(row1);
     _graph.push_back(row2);
     vector<vector<int> > degree_one=check_exceptional(_graph);
     vector<vector<int> > paths;
     paths=find_paths_exceptional(_graph,degree_one);
     for(k=0; k<paths.size(); k++)
     {
       if(paths[k].size()==_graph.size())
       {
         for(l=1; l<=graph.size(); l++) circuit.push_back(paths[k][l]);
         return circuit;
       }
     }
   }
  }
 }
 return circuit;
}
